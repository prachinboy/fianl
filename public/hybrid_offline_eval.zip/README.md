
# Hybrid Offline Evaluation (Content+Apriori)

ชุดทดสอบผลลัพธ์ของระบบแนะนำ (แบบไม่ใช้ LSTM/API ภายนอก) โดย **เรียกใช้ recommendHybrid.js ของโปรเจกต์คุณโดยตรง**

## วิธีใช้เร็วสุด
1) แตกไฟล์โฟลเดอร์นี้ไว้ข้างๆโปรเจกต์ Vue ของคุณ
2) ตั้งค่าไฟล์ `.env` (ดู `.env.example`)
3) รันแบบใช้ข้อมูลจาก Firestore:
```
npm i
npm run eval:firestore
```
หรือรันแบบใช้ JSON export:
```
npm i
npm run eval:json
```

## โหมด Firestore
ต้องมี Service Account JSON และ Project ID

## โหมด JSON
วางไฟล์ `data/like_dishes_logs.json` และ `data/users.json` ตามตัวอย่างใน `data/example/`

## Output
- สรุปเมตริก: HitRate@K, Precision@K, Recall@K, MAP@K, NDCG@K
- รายคน (top-5 แนะนำ vs เมนูที่ผู้ใช้ไปกดจริงในอนาคตหนึ่งรายการ)
- รองรับ Daily (limit=3) / Weekly (limit=21)
