
import 'dotenv/config'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import chalk from 'chalk'
import _ from 'lodash'
import { format } from 'date-fns'
import { precision, recall, hitRate, apk, ndcg } from './utils/metrics.js'
import { buildProfile } from './utils/profile.js'

const args = process.argv.slice(2)
const source = args.includes('--source=json') ? 'json' : 'firestore'
const K = 5
const DAILY_LIMIT = 3
const WEEKLY_LIMIT = 21

async function loadEngine() {
  const RECO_ROOT = process.env.RECO_ROOT
  if (!RECO_ROOT) throw new Error('กรุณาตั้งค่า RECO_ROOT ใน .env ให้ชี้ไปยังโฟลเดอร์ utils ของโปรเจกต์คุณ')
  const f = path.resolve(RECO_ROOT, 'recommendHybrid.js')
  const mod = await import(pathToFileURL(f).href)
  const fn = mod.default || mod.recommendHybrid
  if (!fn) throw new Error('ไม่พบ export recommendHybrid จากไฟล์ ' + f)
  return fn
}

async function loadData() {
  if (source === 'json') {
    const { loadJSON } = await import('./datasource/json.js')
    const users = loadJSON(process.env.JSON_USERS || './data/example/users.json')
    const logs = loadJSON(process.env.JSON_LIKE_LOGS || './data/example/like_dishes_logs.json')
    // normalize timestamp
    logs.forEach(l => l.timestamp = new Date(l.timestamp))
    return { users, logs }
  } else {
    const { initAdmin, fetchUsers, fetchLikeLogs } = await import('./datasource/firestore.js')
    const db = initAdmin()
    const users = await fetchUsers(db)
    const logs = await fetchLikeLogs(db)
    logs.forEach(l => {
      if (l.timestamp && l.timestamp.toDate) l.timestamp = l.timestamp.toDate()
    })
    return { users, logs }
  }
}

function splitTrainTest(logsByUser, testCount=1) {
  const train = {}, test = {}
  for (const [email, arr] of Object.entries(logsByUser)) {
    const sorted = _.sortBy(arr, x => x.timestamp)
    test[email] = sorted.slice(-testCount)
    train[email] = sorted.slice(0, Math.max(0, sorted.length - testCount))
  }
  return { train, test }
}

async function main() {
  console.log(chalk.cyan('⭐ Hybrid Offline Evaluation — source = ' + source))
  const recommendHybrid = await loadEngine()
  const { users, logs } = await loadData()

  const logsByUser = _.groupBy(logs, 'email')
  const { train, test } = splitTrainTest(logsByUser, 1) // ทดสอบ 1 รายการล่าสุดต่อผู้ใช้

  let agg = { hr:0, p:0, r:0, map:0, ndcg:0, n:0 }

  for (const u of users) {
    const email = u.email
    const tset = test[email] || []
    if (tset.length === 0) continue
    const truth = new Set(tset.map(x => x.menuname))

    const profile = buildProfile(u)

    // --- ทดสอบโหมด daily ---
    const dailyRes = await recommendHybrid(profile, { limit: DAILY_LIMIT })
    const dailyTop = dailyRes.slice(0, K).map(x => x.name)

    const hr = hitRate(dailyTop, truth)
    const p = precision(dailyTop, truth)
    const r = recall(dailyTop, truth)
    const mapk = apk(dailyTop, truth)
    const n = ndcg(dailyTop, truth)

    agg.hr += hr; agg.p += p; agg.r += r; agg.map += mapk; agg.ndcg += n; agg.n += 1

    console.log(chalk.gray(`User ${email}`))
    console.log('  truth :', [...truth].join(', '))
    console.log('  daily :', dailyTop.join(' | '), chalk.yellow(` HR=${hr} P=${p.toFixed(2)} R=${r.toFixed(2)} MAP=${mapk.toFixed(2)} NDCG=${n.toFixed(2)}`))

    // --- ทดสอบโหมด weekly (ตัวอย่าง: เอา 21 รายการมาตัดท็อป K เพื่อดูคุณภาพอันดับ) ---
    const weeklyRes = await recommendHybrid(profile, { limit: WEEKLY_LIMIT })
    const weeklyTop = weeklyRes.slice(0, K).map(x => x.name)
    const hrW = hitRate(weeklyTop, truth)
    console.log('  weekly:', weeklyTop.join(' | '), chalk.yellow(` HR=${hrW}`))
  }

  if (agg.n === 0) {
    console.log(chalk.red('ไม่พบข้อมูลทดสอบ (ต้องมี like อย่างน้อย 1 รายการ/ผู้ใช้)'))
    return
  }

  console.log(chalk.green('\n=== สรุปเมตริก (เฉลี่ยผู้ใช้) ==='))
  console.log('HitRate@K :', (agg.hr/agg.n).toFixed(3))
  console.log('Precision@K:', (agg.p/agg.n).toFixed(3))
  console.log('Recall@K   :', (agg.r/agg.n).toFixed(3))
  console.log('MAP@K      :', (agg.map/agg.n).toFixed(3))
  console.log('NDCG@K     :', (agg.ndcg/agg.n).toFixed(3))
}

main().catch(err => { console.error(err); process.exit(1) })
