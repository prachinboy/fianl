
import _ from 'lodash'

export function precision(recommended, relevant) {
  const hit = recommended.filter(x => relevant.has(x)).length
  return recommended.length ? hit / recommended.length : 0
}
export function recall(recommended, relevant) {
  const hit = recommended.filter(x => relevant.has(x)).length
  return relevant.size ? hit / relevant.size : 0
}
export function hitRate(recommended, relevant) {
  return recommended.some(x => relevant.has(x)) ? 1 : 0
}
export function apk(recommended, relevant) {
  let score = 0, hits = 0
  recommended.forEach((item, i) => {
    if (relevant.has(item)) {
      hits += 1
      score += hits / (i + 1)
    }
  })
  return relevant.size ? score / Math.min(recommended.length, relevant.size) : 0
}
export function ndcg(recommended, relevant) {
  const dcg = recommended.reduce((acc, item, i) => acc + (relevant.has(item) ? 1 / Math.log2(i + 2) : 0), 0)
  const ideal = [...Array(Math.min(relevant.size, recommended.length)).keys()].reduce((acc, i) => acc + 1 / Math.log2(i + 2), 0)
  return ideal ? dcg / ideal : 0
}
