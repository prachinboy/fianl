
export function buildProfile(userDoc) {
  return {
    favoriteMeat: userDoc.favoriteMeat || userDoc.favoritemeat || '',
    favoriteVegetables: userDoc.favoriteVegetables || userDoc.favoritevegetables || '',
    favoriteSpices: userDoc.favoriteSpices || userDoc.favoritespices || '',
    favoriteMethod: userDoc.favoriteMethod || userDoc.favoritemethod || '',
  }
}
